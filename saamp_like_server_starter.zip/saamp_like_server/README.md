# SAAMP-like Multiplayer Server Starter

This is an original, clean-room C++ multiplayer-server starter project.
It is **not the proprietary SA-MP source code** and does not include Rockstar/SA-MP assets,
protocol implementations, or copyrighted game binaries.

## Included

- C++17 server
- UDP networking
- Player connect/disconnect tracking
- Lightweight text command protocol
- `/help`, `/players`, `/ping`
- Config file
- CMake build
- Windows and Linux/macOS socket support

## Build

### Linux/macOS

```bash
cmake -S . -B build
cmake --build build
./build/saamp_server
```

### Windows

```powershell
cmake -S . -B build
cmake --build build --config Release
.\build\Release\saamp_server.exe
```

The server listens on UDP port 7777 by default.

## Protocol

This starter uses a simple newline-delimited UDP protocol:

- `CONNECT <name>`
- `CHAT <message>`
- `/help`
- `/players`
- `/ping`
- `DISCONNECT`

This is intentionally a small foundation rather than a drop-in SA-MP replacement.
A real GTA multiplayer client requires a compatible client implementation, packet
serialization, synchronization, authentication, and integration with the game.
