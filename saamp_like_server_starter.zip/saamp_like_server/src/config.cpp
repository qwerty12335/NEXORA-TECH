#include "config.hpp"

#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>

namespace {
std::string trim(std::string s) {
    auto not_space = [](unsigned char c) { return !std::isspace(c); };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), not_space));
    s.erase(std::find_if(s.rbegin(), s.rend(), not_space).base(), s.end());
    return s;
}
}

Config load_config(const std::string& path) {
    Config cfg;
    std::ifstream file(path);
    if (!file) return cfg;

    std::string line;
    while (std::getline(file, line)) {
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;

        const auto pos = line.find('=');
        if (pos == std::string::npos) continue;

        const std::string key = trim(line.substr(0, pos));
        const std::string value = trim(line.substr(pos + 1));

        try {
            if (key == "host") cfg.host = value;
            else if (key == "port") cfg.port = static_cast<unsigned short>(std::stoi(value));
            else if (key == "max_players") cfg.max_players = std::stoi(value);
            else if (key == "server_name") cfg.server_name = value;
        } catch (...) {
            // Ignore malformed individual settings and keep defaults.
        }
    }
    return cfg;
}
