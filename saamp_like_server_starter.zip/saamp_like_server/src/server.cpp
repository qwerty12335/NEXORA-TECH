#include "server.hpp"

#include <algorithm>
#include <cstring>
#include <iostream>
#include <sstream>
#include <vector>

#ifdef _WIN32
    #define NOMINMAX
    #include <winsock2.h>
    #include <ws2tcpip.h>
    using Socket = SOCKET;
    constexpr Socket INVALID_SOCKET_VALUE = INVALID_SOCKET;
#else
    #include <arpa/inet.h>
    #include <cerrno>
    #include <fcntl.h>
    #include <netinet/in.h>
    #include <sys/socket.h>
    #include <unistd.h>
    using Socket = int;
    constexpr Socket INVALID_SOCKET_VALUE = -1;
#endif

struct Server::Impl {
    Socket socket = INVALID_SOCKET_VALUE;
    std::unordered_map<std::string, Player> players;
    std::uint32_t next_id = 1;
};

namespace {
void close_socket(Socket s) {
#ifdef _WIN32
    closesocket(s);
#else
    close(s);
#endif
}

bool set_nonblocking(Socket s) {
#ifdef _WIN32
    u_long mode = 1;
    return ioctlsocket(s, FIONBIO, &mode) == 0;
#else
    const int flags = fcntl(s, F_GETFL, 0);
    return flags >= 0 && fcntl(s, F_SETFL, flags | O_NONBLOCK) == 0;
#endif
}

std::string endpoint_string(const sockaddr_in& addr) {
    char ip[INET_ADDRSTRLEN]{};
    inet_ntop(AF_INET, &addr.sin_addr, ip, sizeof(ip));
    return std::string(ip);
}
}

Server::Server(Config config)
    : impl_(new Impl), config_(std::move(config)) {}

Server::~Server() {
    stop();
    delete impl_;
}

bool Server::start() {
#ifdef _WIN32
    WSADATA data{};
    if (WSAStartup(MAKEWORD(2, 2), &data) != 0) return false;
#endif

    impl_->socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (impl_->socket == INVALID_SOCKET_VALUE) {
#ifdef _WIN32
        WSACleanup();
#endif
        return false;
    }

    sockaddr_in bind_address{};
    bind_address.sin_family = AF_INET;
    bind_address.sin_port = htons(config_.port);

    if (config_.host == "0.0.0.0") {
        bind_address.sin_addr.s_addr = htonl(INADDR_ANY);
    } else if (inet_pton(AF_INET, config_.host.c_str(),
                         &bind_address.sin_addr) != 1) {
        close_socket(impl_->socket);
        impl_->socket = INVALID_SOCKET_VALUE;
#ifdef _WIN32
        WSACleanup();
#endif
        return false;
    }

    int reuse = 1;
    setsockopt(impl_->socket, SOL_SOCKET, SO_REUSEADDR,
#ifdef _WIN32
               reinterpret_cast<const char*>(&reuse), sizeof(reuse)
#else
               &reuse, sizeof(reuse)
#endif
    );

    if (bind(impl_->socket, reinterpret_cast<sockaddr*>(&bind_address),
             sizeof(bind_address)) != 0) {
        close_socket(impl_->socket);
        impl_->socket = INVALID_SOCKET_VALUE;
#ifdef _WIN32
        WSACleanup();
#endif
        return false;
    }

    if (!set_nonblocking(impl_->socket)) {
        close_socket(impl_->socket);
        impl_->socket = INVALID_SOCKET_VALUE;
#ifdef _WIN32
        WSACleanup();
#endif
        return false;
    }

    running_ = true;
    return true;
}

void Server::stop() {
    if (!running_) return;
    running_ = false;

    if (impl_->socket != INVALID_SOCKET_VALUE) {
        close_socket(impl_->socket);
        impl_->socket = INVALID_SOCKET_VALUE;
    }

#ifdef _WIN32
    WSACleanup();
#endif
}

void Server::send_text(const std::string& address, std::uint16_t port,
                       const std::string& text) {
    sockaddr_in target{};
    target.sin_family = AF_INET;
    target.sin_port = htons(port);

    if (inet_pton(AF_INET, address.c_str(), &target.sin_addr) != 1) return;

    sendto(impl_->socket, text.data(), static_cast<int>(text.size()), 0,
           reinterpret_cast<const sockaddr*>(&target), sizeof(target));
}

void Server::handle_packet(const char* data, std::size_t length,
                           const std::string& address, std::uint16_t port) {
    std::string message(data, length);

    if (message.rfind("CONNECT ", 0) == 0) {
        if (static_cast<int>(impl_->players.size()) >= config_.max_players) {
            send_text(address, port, "ERROR Server is full");
            return;
        }

        std::string name = message.substr(8);
        if (name.empty() || name.size() > 24) {
            send_text(address, port, "ERROR Invalid name");
            return;
        }

        const std::string key = address + ":" + std::to_string(port);
        if (impl_->players.contains(key)) {
            send_text(address, port, "ERROR Already connected");
            return;
        }

        Player player;
        player.id = impl_->next_id++;
        player.name = name;
        player.address = key;
        impl_->players.emplace(key, player);

        send_text(address, port,
                  "WELCOME " + std::to_string(player.id) + " " +
                  config_.server_name);
        std::cout << "[CONNECT] #" << player.id << " " << name
                  << " from " << key << '\n';
        return;
    }

    const std::string key = address + ":" + std::to_string(port);
    auto it = impl_->players.find(key);
    if (it == impl_->players.end()) {
        send_text(address, port, "ERROR Connect first");
        return;
    }

    if (message == "DISCONNECT") {
        std::cout << "[DISCONNECT] #" << it->second.id << " "
                  << it->second.name << '\n';
        impl_->players.erase(it);
        return;
    }

    if (message == "/help") {
        send_text(address, port,
                  "COMMANDS /help /players /ping CHAT <message> DISCONNECT");
        return;
    }

    if (message == "/ping") {
        send_text(address, port, "PONG");
        return;
    }

    if (message == "/players") {
        std::ostringstream out;
        out << "PLAYERS " << impl_->players.size();
        for (const auto& [_, player] : impl_->players) {
            out << " #" << player.id << ":" << player.name;
        }
        send_text(address, port, out.str());
        return;
    }

    if (message.rfind("CHAT ", 0) == 0) {
        const std::string chat = message.substr(5);
        if (chat.empty() || chat.size() > 256) {
            send_text(address, port, "ERROR Invalid chat message");
            return;
        }

        const std::string outgoing =
            "CHAT #" + std::to_string(it->second.id) + " " +
            it->second.name + ": " + chat;

        for (const auto& [player_key, player] : impl_->players) {
            const auto separator = player_key.find(':');
            const auto player_address = player_key.substr(0, separator);
            const auto player_port =
                static_cast<std::uint16_t>(std::stoi(player_key.substr(separator + 1)));
            send_text(player_address, player_port, outgoing);
        }
        return;
    }

    send_text(address, port, "ERROR Unknown command");
}

void Server::run() {
    std::vector<char> buffer(4096);

    while (running_) {
        sockaddr_in sender{};
#ifdef _WIN32
        int sender_len = sizeof(sender);
#else
        socklen_t sender_len = sizeof(sender);
#endif

        const int received = recvfrom(
            impl_->socket, buffer.data(), static_cast<int>(buffer.size()), 0,
            reinterpret_cast<sockaddr*>(&sender), &sender_len);

        if (received > 0) {
            const std::string address = endpoint_string(sender);
            const std::uint16_t port = ntohs(sender.sin_port);
            handle_packet(buffer.data(), static_cast<std::size_t>(received),
                          address, port);
        }

#ifdef _WIN32
        Sleep(1);
#else
        usleep(1000);
#endif
    }
}
