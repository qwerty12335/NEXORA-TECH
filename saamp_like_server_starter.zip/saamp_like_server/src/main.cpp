#include "config.hpp"
#include "server.hpp"

#include <iostream>

int main() {
    const Config config = load_config("server.cfg");

    std::cout << "Starting " << config.server_name << '\n';
    std::cout << "Listening on " << config.host << ':' << config.port << '\n';

    Server server(config);
    if (!server.start()) {
        std::cerr << "Failed to start server.\n";
        return 1;
    }

    server.run();
    return 0;
}
