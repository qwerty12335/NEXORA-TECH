#pragma once

#include "config.hpp"
#include <cstdint>
#include <string>
#include <unordered_map>

struct Player {
    std::uint32_t id{};
    std::string name;
    std::string address;
};

class Server {
public:
    explicit Server(Config config);
    ~Server();

    bool start();
    void run();
    void stop();

private:
    struct Impl;
    Impl* impl_;
    Config config_;
    bool running_ = false;

    void handle_packet(const char* data, std::size_t length,
                       const std::string& address, std::uint16_t port);
    void send_text(const std::string& address, std::uint16_t port,
                   const std::string& text);
};
