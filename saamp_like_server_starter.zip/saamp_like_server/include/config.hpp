#pragma once
#include <string>

struct Config {
    std::string host = "0.0.0.0";
    unsigned short port = 7777;
    int max_players = 100;
    std::string server_name = "SAAMP Development Server";
};

Config load_config(const std::string& path);
